
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import Link from "next/link";

export default async function MyPage() {
  const session = await auth();
  if (!session?.user) return <div className="card">Please <Link className="underline" href="/login">login</Link>.</div>;
  const userId = (session.user as any).id;

  const [created, claims] = await Promise.all([
    prisma.task.findMany({
      where: { creatorId: userId },
      include: { claims: { include: { worker: true } } },
      orderBy: { createdAt: "desc" },
    }),
    prisma.claim.findMany({
      where: { workerId: userId },
      include: { task: true },
      orderBy: { createdAt: "desc" },
    }),
  ]);

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <div>
        <h2 className="text-xl font-semibold mb-3">My Created Tasks</h2>
        <div className="space-y-4">
          {created.map(t => (
            <div key={t.id} className="card">
              <div className="flex items-center justify-between">
                <div className="font-medium">{t.type.toLowerCase()} • ⭐ {t.rewardPoints}</div>
                <div className="text-xs text-slate-500">{t.maxClaims - t.claimsCount}/{t.maxClaims} left</div>
              </div>
              <div className="text-sm mt-1 break-all"><a className="underline text-blue-600" href={t.tweetUrl} target="_blank">{t.tweetUrl}</a></div>
              <div className="mt-3">
                <h4 className="font-semibold text-sm mb-2">Claims</h4>
                <div className="space-y-2">
                  {t.claims.length === 0 && <div className="text-sm text-slate-500">No claims yet.</div>}
                  {t.claims.map(c => (
                    <div key={c.id} className="flex items-center justify-between border rounded-lg px-3 py-2">
                      <a href={c.proofUrl} target="_blank" className="text-sm underline text-blue-600 break-all">{c.proofUrl}</a>
                      <div className="flex items-center gap-2">
                        <span className="text-xs">{c.status}</span>
                        {c.status === "PENDING" && (
                          <form action={`/api/claims/${c.id}/approve`} method="post">
                            <button className="btn btn-primary text-xs">Approve</button>
                          </form>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div>
        <h2 className="text-xl font-semibold mb-3">My Work (Claims)</h2>
        <div className="space-y-4">
          {claims.map(c => (
            <div key={c.id} className="card">
              <div className="flex items-center justify-between">
                <div className="font-medium">{c.task.type.toLowerCase()} • ⭐ {c.task.rewardPoints}</div>
                <div className="text-xs">{c.status}</div>
              </div>
              <div className="text-sm mt-1">
                Tweet: <a className="underline text-blue-600 break-all" href={c.task.tweetUrl} target="_blank">{c.task.tweetUrl}</a>
              </div>
              <div className="text-sm mt-1">
                Proof: <a className="underline text-blue-600 break-all" href={c.proofUrl} target="_blank">{c.proofUrl}</a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
