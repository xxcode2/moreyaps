
"use client";
import { signIn } from "next-auth/react";

export default function LoginPage() {
  return (
    <div className="max-w-md mx-auto card">
      <h1 className="text-xl font-semibold mb-4">Login</h1>
      <div className="space-y-3">
        <button className="btn w-full" onClick={() => signIn("github")}>Continue with GitHub</button>
        <button className="btn w-full" onClick={() => signIn("google")}>Continue with Google</button>
      </div>
      <p className="text-xs text-slate-500 mt-4">You need to login to create or claim tasks.</p>
    </div>
  );
}
