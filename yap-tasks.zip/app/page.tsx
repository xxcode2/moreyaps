
import { prisma } from "@/lib/prisma";
import TaskCard from "@/components/TaskCard";

export default async function Home() {
  const tasks = await prisma.task.findMany({
    where: { status: "ACTIVE" },
    include: { creator: { select: { name: true, image: true } } },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Open Tasks</h1>
      {tasks.length === 0 && <div className="card">No active tasks yet.</div>}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {tasks.map(t => <TaskCard key={t.id} task={t} creator={t.creator} />)}
      </div>
    </div>
  );
}
