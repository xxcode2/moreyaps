
import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const userId = (session.user as any).id;
  const form = await req.formData();
  const proofUrl = String(form.get("proofUrl") || "");

  const taskId = params.id;

  const res = await prisma.$transaction(async (tx) => {
    const task = await tx.task.findUnique({ where: { id: taskId } });
    if (!task) throw new Error("Task not found");
    if (task.status !== "ACTIVE") throw new Error("Task not active");
    if (task.claimsCount >= task.maxClaims) throw new Error("No slots left");

    // prevent duplicate claims by same user
    const existing = await tx.claim.findFirst({ where: { taskId, workerId: userId } });
    if (existing) throw new Error("You already claimed this task");

    const claim = await tx.claim.create({
      data: { taskId, workerId: userId, proofUrl },
    });

    // increment claimsCount
    await tx.task.update({
      where: { id: taskId },
      data: { claimsCount: { increment: 1 } },
    });

    return claim;
  }).catch((e) => ({ error: e.message }));

  if ("error" in res) return NextResponse.json(res, { status: 400 });
  return NextResponse.redirect(new URL(`/my`, req.url));
}
