export default function Loading(){return <div className='card'>Loading…</div>}
