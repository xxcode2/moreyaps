
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import Link from "next/link";

export default async function TaskDetail({ params }: { params: { id: string } }) {
  const session = await auth();
  const task = await prisma.task.findUnique({
    where: { id: params.id },
    include: { creator: true },
  });
  if (!task) return <div className="card">Task not found.</div>;

  return (
    <div className="space-y-4">
      <div className="card">
        <div className="flex items-center justify-between">
          <div className="font-semibold text-lg">{task.type.toLowerCase()} task by {task.creator.name ?? "Anon"}</div>
          <div className="text-sm">⭐ {task.rewardPoints} / claim</div>
        </div>
        <div className="mt-2 text-sm">
          Tweet URL: <a className="text-blue-600 underline break-all" href={task.tweetUrl} target="_blank">{task.tweetUrl}</a>
        </div>
        <div className="mt-1 text-xs text-slate-500">Slots left: {task.maxClaims - task.claimsCount} / {task.maxClaims}</div>
      </div>

      <div className="card">
        <h3 className="font-semibold mb-2">Submit Proof</h3>
        {!session && <div>Please <Link href="/login" className="underline">login</Link> to submit.</div>}
        {session && (
          <form action={`/api/tasks/${task.id}/claim`} method="post" className="space-y-3">
            <input type="hidden" name="taskId" value={task.id} />
            <label className="label">Proof URL (your like/retweet/reply link or profile for follow)</label>
            <input name="proofUrl" required placeholder="https://x.com/yourname/status/..." className="input" />
            <button className="btn-primary btn" type="submit">Claim</button>
            <p className="text-xs text-slate-500">Auto-verification via X API is optional; by default, creator reviews claims.</p>
          </form>
        )}
      </div>
    </div>
  );
}
