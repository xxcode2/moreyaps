
import Link from "next/link";
import { Task, TaskStatus, TaskType, User } from "@prisma/client";

export default function TaskCard({ task, creator }: { task: Task, creator: Pick<User, "name" | "image"> }) {
  const left = task.maxClaims - task.claimsCount;
  const typeLabel = task.type.toLowerCase();
  return (
    <div className="card">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          {creator.image && <img src={creator.image} className="w-10 h-10 rounded-full border" />}
          <div>
            <div className="font-semibold">{creator.name ?? "Anon"}</div>
            <div className="text-xs text-slate-500">Task: {typeLabel}</div>
          </div>
        </div>
        <div className="text-right">
          <div className="text-sm">⭐ {task.rewardPoints} / claim</div>
          <div className="text-xs text-slate-500">{left} of {task.maxClaims} left</div>
        </div>
      </div>
      <div className="mt-4 space-y-2">
        <div className="text-sm"><span className="font-medium">Tweet:</span> <a className="text-blue-600 underline break-all" href={task.tweetUrl} target="_blank">{task.tweetUrl}</a></div>
        <div className="flex gap-2">
          <Link href={`/task/${task.id}`} className="btn-primary btn">Open</Link>
        </div>
      </div>
    </div>
  );
}
