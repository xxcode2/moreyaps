export default { reactStrictMode: true, experimental: { serverActions: { bodySizeLimit: "2mb" } } }
